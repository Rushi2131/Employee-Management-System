import React from 'react'

const FooterComponent = () => {
  return (
    <div>
        <footer className='footer'>
            <h6>Hello from footer</h6>
        </footer>
    </div>
  )
}

export default FooterComponent